<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Guru</title>
    <link rel="icon" type="image/png" href="https://smpn1mayong.sch.id/images/download-removebg-preview1.png">

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            display: flex;
            height: 100vh;
        }

        .sidebar {
            width: 250px;
            background-color: #4e73df;
            color: #fff;
            padding: 20px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        }

        .sidebar h2 {
            margin: 0 0 20px;
        }

        .sidebar img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin: 10px 0;
        }

        .sidebar a {
            display: block;
            color: #fff;
            text-decoration: none;
            margin: 15px 0;
            font-size: 18px;
        }

        .sidebar a:hover {
            background-color: #3759c1;
            padding-left: 10px;
        }

        .content {
            flex-grow: 1;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center; /* Pusatkan elemen di tengah */
        }

        .card-container {
            display: flex;
            flex-wrap: wrap;
            gap: 15px; /* Jarak antar card */
            justify-content: flex-start; /* Mulai dari tengah */
            width: 100%;
            max-width: 900px; /* Membatasi lebar maksimal */
        }

        .card {
            width: calc(20% - 10px); /* Ukuran card lebih kecil */
            min-width: 150px; /* Mengurangi nilai min-width */
            max-width: 200px; /* Mengurangi nilai max-width */
            text-align: center;
            padding: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            background-color: #fff;

        }

        .card .card-title {
            font-size: 16px;
            margin-bottom: 10px;
        }

        .card .card-icon-large {
            text-align: center;
            margin: 0 auto;
        }

        .card .card-icon-large .icon-img {
            width: 50px;
            height: 50px;
            object-fit: contain;
            margin-bottom: 10px;
        }

        .progress {
            height: 8px;
            background-color: #e0e0e0;
            border-radius: 5px;
            overflow: hidden;
        }

        .progress-bar {
            height: 100%;
            border-radius: 5px;
        }

        .l-bg-cherry {
            background: linear-gradient(to right, #493240, #f09) !important;
            color: #fff;
        }

        .l-bg-blue-dark {
            background: linear-gradient(to right, #373b44, #4286f4) !important;
            color: #fff;
        }

        .l-bg-green-dark {
            background: linear-gradient(to right, #0a504a, #38ef7d) !important;
            color: #fff;
        }

        .l-bg-orange-dark {
            background: linear-gradient(to right, #a86008, #ffba56) !important;
            color: #fff;
        }

        /* Information box styling */
.info-box {
    background-color: #f8f9fc;
    border: 1px solid #ddd;
    padding: 15px;
    margin-top: 20px;
    border-radius: 5px;
    display: flex;
    align-items: center;
    justify-content: flex-start;
}

.info-box img {
    width: 30px;  /* Mengecilkan gambar */
    height: 30px; /* Mengecilkan gambar */
    margin-right: 15px;
}

.info-box p {
    font-size: 14px;
    color: #333;
}

/* Styling untuk teks informasi */
.info-title {
    color: red; /* Menjadikan teks merah */
    font-weight: bold; /* Menjadikan teks bold */
}


    </style>
</head>

<body>
    <div class="sidebar">
        <h2>Dashboard Guru</h2>
        <img src="https://static.vecteezy.com/system/resources/previews/000/439/863/non_2x/vector-users-icon.jpg" alt="Foto Profil">
        <div class="username"> Pak Tegar </div>
        <a href="dashboard-guru.php">Dashboard</a>
        <a href="profile.php">Profil</a>
        <a href="jadwal-pelajaran.php">Jadwal Pelajaran</a>
        <a href="materi-pelajaran.php">Materi Pelajaran</a>
        <a href="data-siswa.php">Data Siswa</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="content">
        <h1>Selamat Datang, Guru!</h1>
        <div class="card-container">
            <!-- Card 1 -->
            <div class="card l-bg-cherry">
                <div class="card-icon-large">
                    <img src="https://static.vecteezy.com/system/resources/previews/020/911/740/non_2x/user-profile-icon-profile-avatar-user-icon-male-icon-face-icon-profile-icon-free-png.png" alt="Jumlah Siswa" class="icon-img">
                </div>
                <h5 class="card-title">Jumlah Siswa</h5>
                <h2>100</h2>
                <div class="progress">
                    <div class="progress-bar" style="width: 25%; background-color: #289cf5;"></div>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="card l-bg-blue-dark">
                <div class="card-icon-large">
                    <img src="https://static.vecteezy.com/system/resources/previews/020/911/740/non_2x/user-profile-icon-profile-avatar-user-icon-male-icon-face-icon-profile-icon-free-png.png" alt="Jumlah Guru" class="icon-img">
                </div>
                <h5 class="card-title">Jumlah Guru</h5>
                <h2>20</h2>
                <div class="progress">
                    <div class="progress-bar" style="width: 50%; background-color: #23bdb8;"></div>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="card l-bg-orange-dark">
                <div class="card-icon-large">
                    <img src="https://png.pngtree.com/png-vector/20230412/ourmid/pngtree-process-flat-icon-vector-png-image_6701344.png" alt="Kegiatan Aktif" class="icon-img">
                </div>
                <h5 class="card-title">Kegiatan Aktif</h5>
                <h2>15</h2>
                <div class="progress">
                    <div class="progress-bar" style="width: 75%; background-color: #f9900e;"></div>
                </div>
            </div>

            <!-- Card 4 -->
            <div class="card l-bg-green-dark">
                <div class="card-icon-large">
                    <img src="asset\image_2025-01-21_161453720-removebg-preview.png" alt="Materi Tersedia" class="icon-img">
                </div>
                <h5 class="card-title">Materi Tersedia</h5>
                <h2>50</h2>
                <div class="progress">
                    <div class="progress-bar" style="width: 60%; background-color: #0a504a;"></div>
                </div>
            </div>
        </div>
        <hr>
         <!-- Information Box Below Card -->
         <div class="info-box">
            <img src="https://png.pngtree.com/png-clipart/20220901/ourmid/pngtree-3d-red-portable-megaphone-speaker-announcement-and-promotion-png-image_6133300.png" alt="Announcement Logo">
            <p><strong class="info-title">Informasi:</strong> Pastikan Anda telah mendaftar untuk mendapatkan akses ke materi e-learning SMPN 1 Mayong.</p>
        </div>
    </div>
    </div>
</body>

</html>
