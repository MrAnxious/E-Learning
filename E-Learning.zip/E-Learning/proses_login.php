<?php
session_start();

// Simulasi data pengguna
$users = [
    'admin' => ['username' => 'admin', 'password' => 'admin123', 'role' => 'admin'],
    'guru' => ['username' => 'guru', 'password' => 'guru123', 'role' => 'guru'],
    'murid' => ['username' => 'murid', 'password' => 'murid123', 'role' => 'murid']
];

// Proses login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    foreach ($users as $user) {
        if ($user['username'] === $username && $user['password'] === $password) {
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $user['role'];

            // Redirect sesuai role
            switch ($user['role']) {
                case 'admin':
                    header("Location: dashboard-admin.php");
                    exit;
                case 'guru':
                    header("Location: dashboard-guru.php");
                    exit;
                case 'murid':
                    header("Location: dashboard-murid.php");
                    exit;
            }
        }
    }

    // Jika username/password salah
    header("Location: login.php?error=" . urlencode("Username atau password salah!"));
    exit;
}

// Jika akses langsung ke file ini
header("Location: login.php");
exit;
?>
