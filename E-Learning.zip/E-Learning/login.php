<?php
session_start();
if (isset($_SESSION['role'])) {
    switch ($_SESSION['role']) {
        case 'admin':
            header("Location: dashboard-admin.php");
            exit;
        case 'guru':
            header("Location: dashboard-guru.php");
            exit;
        case 'murid':
            header("Location: dashboard-murid.php");
            exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Sistem E-Learning SMPN 1 Mayong</title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="https://smpn1mayong.sch.id/images/download-removebg-preview1.png">

    <!-- Font Awesome for Eye Icon -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

    <style>
        /* General styling */
        body {
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: url('https://smpn1mayong.sch.id/images/Gambar/gedungsmpn.jpeg') no-repeat center center;
            background-size: cover;
            font-family: 'Nunito', sans-serif;
        }

        /* Card styling */
        .card {
            background-color: rgba(255, 255, 255, 0.9);
            width: 100%;
            max-width: 400px;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            text-align: center;
            animation: fadeInUp 1.2s ease-out;
        }

        /* Logo styling with animation */
        .logo {
            width: 190px;
            margin-bottom: 20px;
            animation: zoomIn 1s ease-out;
        }

        /* Header styling */
        h2 {
            font-weight: bold;
            margin: 10px 0;
            animation: fadeInUp 1s ease-out;
        }

        /* Form input styling */
        .form-control {
            font-size: 14px;
            padding: 10px 15px;
            border-radius: 5px;
            border: 1px solid #ddd;
            width: 100%;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

        /* Button styling */
        .btn {
            background-color: #4e73df;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            padding: 12px 20px;
            width: 100%;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        /* Hover effect for button */
        .btn:hover {
            background-color: #3759c1;
            transform: translateY(-3px);
        }

        /* Password visibility icon position */
        .password-container {
            position: relative;
        }

        .password-container span {
            position: absolute;
            right: 10px;
            top: 8px;
            cursor: pointer;
            z-index: 10;
        }

        /* Styling for the eye icon */
        .fa-eye,
        .fa-eye-slash {
            font-size: 18px;
        }

    </style>
</head>

<body>
    <div class="card">
        <img src="https://smpn1mayong.sch.id/images/download-removebg-preview1.png" alt="Logo SMPN 1 Mayong" class="logo">
        <h2>E-LEARNING</h2>
        <h2>SMP NEGERI 1 MAYONG</h2>
        <form class="user" method="POST" action="proses-login.php">
            <input type="email" class="form-control" placeholder="Masukkan Email Anda..." required>
            <div class="password-container">
                <input type="password" id="password" class="form-control" placeholder="Masukkan Password..." required>
                <span onclick="togglePassword()">
                    <i id="toggleIcon" class="fas fa-eye"></i>
                </span>
            </div>
            <button type="submit" class="btn">Login</button>
        </form>
        <hr>
        <a href="reset-password.php" class="reset-link">
            <h3>Lupa Password?</h3>
        </a>
        <div class="footer">
            &copy; <span id="year"></span> SMPN 1 Mayong. All Rights Reserved.
        </div>
    </div>

    <!-- JavaScript -->
    <script>
        // Tahun otomatis
        document.getElementById("year").textContent = new Date().getFullYear();

        // Toggle password visibility
        function togglePassword() {
            const passwordField = document.getElementById("password");
            const toggleIcon = document.getElementById("toggleIcon");
            if (passwordField.type === "password") {
                passwordField.type = "text";
                toggleIcon.classList.remove("fa-eye");
                toggleIcon.classList.add("fa-eye-slash");
            } else {
                passwordField.type = "password";
                toggleIcon.classList.remove("fa-eye-slash");
                toggleIcon.classList.add("fa-eye");
            }
        }
    </script>
</body>

</html>
